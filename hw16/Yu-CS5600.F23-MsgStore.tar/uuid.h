#ifndef UUID_H
#define UUID_H

void generate_uuid(char* uuid);

#endif