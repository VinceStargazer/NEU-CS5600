int stringLen(const char *str);
int stringEndsWith(const char *str1, const char *str2);
int isStringEqual(const char *str1, const char *str2);