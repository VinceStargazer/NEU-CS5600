To compile this program:
`make`  
To run this program:
`java Main`