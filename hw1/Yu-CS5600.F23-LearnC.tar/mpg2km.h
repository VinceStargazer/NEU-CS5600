float mpg2kml(float mpg);
float mpg2lphm(float mpg);
float lph2mpg(float lph);