#ifndef GET_ENV_H
#define GET_ENV_H

int get_env_var(char* target);

#endif