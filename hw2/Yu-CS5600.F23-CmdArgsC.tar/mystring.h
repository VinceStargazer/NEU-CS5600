int stringLen(const char *str);
void appendString(char *dest, const char *src);
int isStringEqual(const char *str1, const char *str2);
void stringToUpper(char* str);
void stringToLower(char* str);
void stringToCap(char* str);